﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class Shelf
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string? RowLayout { get; set; }

        public int RowCount { get; set; } = 5;   
        public int SlotsPerRow { get; set; } = 9; 
    }
}
