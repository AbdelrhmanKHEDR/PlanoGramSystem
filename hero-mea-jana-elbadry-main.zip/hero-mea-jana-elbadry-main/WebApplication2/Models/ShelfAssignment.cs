﻿namespace WebApplication2.Models
{
    public class ShelfAssignment
    {
        public int Id { get; set; }

        public int ProductId { get; set; }
        public Product Product { get; set; }

        public int ShelfId { get; set; }
        public Shelf Shelf { get; set; }

        public int RowNumber { get; set; }   
        public int SlotNumber { get; set; } 
    }
}