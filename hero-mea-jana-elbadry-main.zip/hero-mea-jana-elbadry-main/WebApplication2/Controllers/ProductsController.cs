﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;
        private readonly IConfiguration _configuration;

        public ProductsController(AppDbContext context, IWebHostEnvironment env, IConfiguration configuration)
        {
            _context = context;
            _env = env;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _context.Products.ToListAsync();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product, IFormFile imageFile)
        {
            if (imageFile == null || imageFile.Length == 0)
            {
                ModelState.AddModelError("", "Please select an image for the product.");
                return View(product);
            }

            string uploadsFolder = Path.Combine(_env.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            string uniqueFileName = Guid.NewGuid() + Path.GetExtension(imageFile.FileName);
            string filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await imageFile.CopyToAsync(stream);
            }

            product.ImageUrl = "/uploads/" + uniqueFileName;

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        // Uploads an image, strips its background via remove.bg, and saves the
        // RESULT as a new Product (instead of streaming it back to the browser,
        // which is what was causing the auto-download). No ShelfAssignment is
        // created, so it appears under "Unassigned Products" on the Shelves
        // page automatically.
        [HttpPost]
        public async Task<IActionResult> RemoveBackgroundAndAdd(string name, IFormFile image)
        {
            if (image == null || image.Length == 0)
            {
                TempData["BgRemovalError"] = "Please select an image.";
                return RedirectToAction("Index");
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                TempData["BgRemovalError"] = "Please enter a product name.";
                return RedirectToAction("Index");
            }

            string? apiKey = _configuration["BackgroundRemoval:ApiKey"];
            if (string.IsNullOrEmpty(apiKey))
            {
                TempData["BgRemovalError"] = "Remove.bg API key is missing.";
                return RedirectToAction("Index");
            }

            byte[] resultImage;

            try
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Add("X-Api-Key", apiKey);

                using var form = new MultipartFormDataContent();
                using var stream = image.OpenReadStream();

                var imageContent = new StreamContent(stream);
                imageContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue(image.ContentType);

                form.Add(imageContent, "image_file", image.FileName);
                form.Add(new StringContent("auto"), "size");

                var response = await client.PostAsync("https://api.remove.bg/v1.0/removebg", form);

                if (!response.IsSuccessStatusCode)
                {
                    var errorMessage = await response.Content.ReadAsStringAsync();
                    TempData["BgRemovalError"] = $"Remove.bg error: {errorMessage}";
                    return RedirectToAction("Index");
                }

                resultImage = await response.Content.ReadAsByteArrayAsync();
            }
            catch (Exception ex)
            {
                TempData["BgRemovalError"] = $"Error: {ex.Message}";
                return RedirectToAction("Index");
            }

            string uploadsFolder = Path.Combine(_env.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            // remove.bg always returns a PNG (needed for transparency)
            string uniqueFileName = Guid.NewGuid() + ".png";
            string filePath = Path.Combine(uploadsFolder, uniqueFileName);

            // Fully-qualified to avoid clashing with Controller.File(...)
            await System.IO.File.WriteAllBytesAsync(filePath, resultImage);

            var product = new Product
            {
                Name = name,
                ImageUrl = "/uploads/" + uniqueFileName
            };

            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> AssignShelf([FromBody] AssignShelfRequest request)
        {
            ShelfAssignment existing = null;
            if (request.AssignmentId.HasValue)
            {
                existing = await _context.ShelfAssignments
                    .FirstOrDefaultAsync(a => a.Id == request.AssignmentId.Value);
            }

            if (request.ShelfId == null)
            {
                if (existing != null)
                {
                    _context.ShelfAssignments.Remove(existing);
                    await _context.SaveChangesAsync();
                }
                return Ok();
            }

            var slotTaken = await _context.ShelfAssignments
                .AnyAsync(a => a.ShelfId == request.ShelfId
                            && a.RowNumber == request.RowNumber
                            && a.SlotNumber == request.SlotNumber
                            && (existing == null || a.Id != existing.Id));

            if (slotTaken)
            {
                return BadRequest("That slot is already occupied.");
            }

            if (existing != null)
            {
                existing.ShelfId = request.ShelfId.Value;
                existing.RowNumber = request.RowNumber;
                existing.SlotNumber = request.SlotNumber;

                await _context.SaveChangesAsync();
                return Ok(new { assignmentId = existing.Id });
            }

            var newAssignment = new ShelfAssignment
            {
                ProductId = request.ProductId,
                ShelfId = request.ShelfId.Value,
                RowNumber = request.RowNumber,
                SlotNumber = request.SlotNumber
            };

            _context.ShelfAssignments.Add(newAssignment);
            await _context.SaveChangesAsync();

            return Ok(new { assignmentId = newAssignment.Id });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProduct([FromBody] DeleteProductRequest request)
        {
            var product = await _context.Products.FindAsync(request.ProductId);
            if (product == null) return NotFound();

            var placements = _context.ShelfAssignments.Where(a => a.ProductId == request.ProductId);
            _context.ShelfAssignments.RemoveRange(placements);   // clear it off every shelf first
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return Ok();
        }

        // NEW: saves the per-row layout for the "Default" gondola and the per-row
        // "+" (add container) buttons. The view POSTs here to /Products/UpdateRowLayout.
        // RowLayout is a CSV of container counts per row, row 1 (bottom) first,
        // e.g. "6,12,12,14,14,16,16".
        [HttpPost]
        public async Task<IActionResult> UpdateRowLayout([FromBody] UpdateRowLayoutRequest request)
        {
            var shelf = await _context.Shelves.FindAsync(request.ShelfId);
            if (shelf == null) return NotFound();

            var counts = (request.RowLayout ?? "")
                .Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(s => int.TryParse(s.Trim(), out var v) ? v : 0)
                .ToList();

            if (counts.Count == 0 || counts.Any(c => c < 1))
                return BadRequest("Invalid row layout.");

            shelf.RowLayout = string.Join(",", counts);
            shelf.RowCount = counts.Count;      // keep the row count in sync
            shelf.SlotsPerRow = counts.Max();   // widest row (used elsewhere in the view)

            await _context.SaveChangesAsync();
            return Ok();
        }

        public class DeleteProductRequest { public int ProductId { get; set; } }

        public class UpdateRowLayoutRequest
        {
            public int ShelfId { get; set; }
            public string RowLayout { get; set; }
        }
    }



    public class AssignShelfRequest
    {
        public int ProductId { get; set; }
        public int? ShelfId { get; set; }
        public int RowNumber { get; set; }
        public int SlotNumber { get; set; }
        public int? AssignmentId { get; set; }
    }


}