﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class ShelvesController : Controller
    {
        private readonly AppDbContext _context;

        public ShelvesController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var shelves = await _context.Shelves.ToListAsync();
            var allProducts = await _context.Products.ToListAsync();
            var assignments = await _context.ShelfAssignments.ToListAsync();

            var assignedProductIds = assignments.Select(a => a.ProductId).ToHashSet();

            ViewBag.Assignments = assignments;
            ViewBag.UnassignedProducts = allProducts.Where(p => !assignedProductIds.Contains(p.Id)).ToList();
            ViewBag.AllProducts = allProducts;

            // NEW: hand the per-row "Default" layout to the view (null = uniform mode).
            ViewBag.RowLayout = shelves.FirstOrDefault()?.RowLayout;

            return View(shelves);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Shelf shelf)
        {
            _context.Shelves.Add(shelf);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }



        [HttpPost]
        public async Task<IActionResult> UpdateRowCount([FromBody] UpdateRowCountRequest request)
        {
            var shelf = await _context.Shelves.FindAsync(request.ShelfId);
            if (shelf == null) return NotFound();

            if (request.RowCount < 1)
                return BadRequest("A shelf needs at least 1 row.");

            if (request.RowCount < shelf.RowCount)
            {
                // Jars currently sitting on rows that are about to disappear.
                var displaced = await _context.ShelfAssignments
                    .Where(a => a.ShelfId == shelf.Id && a.RowNumber > request.RowCount)
                    .OrderBy(a => a.RowNumber).ThenBy(a => a.SlotNumber)
                    .ToListAsync();

                // Slots still occupied on the rows we're keeping.
                var kept = await _context.ShelfAssignments
                    .Where(a => a.ShelfId == shelf.Id && a.RowNumber <= request.RowCount)
                    .ToListAsync();
                var taken = new HashSet<(int, int)>(kept.Select(a => (a.RowNumber, a.SlotNumber)));

                // Empty slots on the remaining shelf, filled bottom row (1) first.
                var emptySlots = new List<(int Row, int Slot)>();
                for (int r = 1; r <= request.RowCount; r++)
                    for (int s = 1; s <= shelf.SlotsPerRow; s++)
                        if (!taken.Contains((r, s)))
                            emptySlots.Add((r, s));

                int next = 0;
                foreach (var a in displaced)
                {
                    if (next < emptySlots.Count)
                    {
                        a.RowNumber = emptySlots[next].Row;
                        a.SlotNumber = emptySlots[next].Slot;
                        next++;
                    }
                    else
                    {
                        // No room left on the remaining shelf -> send it back to the tray.
                        _context.ShelfAssignments.Remove(a);
                    }
                }
            }

            shelf.RowCount = request.RowCount;
            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> UpdateSlotsPerRow([FromBody] UpdateSlotsRequest request)
        {
            var shelf = await _context.Shelves.FindAsync(request.ShelfId);
            if (shelf == null) return NotFound();

            if (request.SlotsPerRow < 1)
                return BadRequest("A shelf needs at least 1 slot per row.");

            shelf.SlotsPerRow = request.SlotsPerRow;

            // NEW: picking 9 / 17 / 26 / 34 leaves "Default" mode and returns the
            // shelf to a uniform layout.
            shelf.RowLayout = null;

            await _context.SaveChangesAsync();

            return Ok();
        }
    }

    public class UpdateRowCountRequest
    {
        public int ShelfId { get; set; }
        public int RowCount { get; set; }
    }

    public class UpdateSlotsRequest
    {
        public int ShelfId { get; set; }
        public int SlotsPerRow { get; set; }
    }
}